﻿<?php
	class GoogleSearch
	{
		private $query;
		
		public function __construct($search)
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "http://www.google.com/search?q=$search&num=100&hl=en&biw=1280&bih=612&prmd=ivns&ei=&start=0&sa=N");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLINFO_HEADER_OUT, true); 
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false); 
			$this->query = curl_exec($ch);
					
		}
		
		private function parseRezult()
		{
			$html = new DomDocument();  
			@$html->loadHTML($this->query);
			$html->getElementById('res');
			$this->query = $html->saveHTML();
			
		}
		
		public function getSearch()
		{
			//$this->parseRezult();
			return $this->query;
		}
	
	}
